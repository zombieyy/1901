<?php
	include 'connect.php';
	

    // $conn->set_charset('utf8');
    $result = $conn -> query('select url from where size=""');
    $res = $result->fetch_all(MYSQLI_ASSOC);

    echo json_encode($res,JSON_UNESCAPED_UNICODE);
    $result->close();
    // $conn->close();



	




?>