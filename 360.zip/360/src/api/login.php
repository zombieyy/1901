<?php
	
	include "connect.php";
   

	$logSql = 'select * from reg';
	$result = $conn->query($logSql);
	$logSqlArr = $result -> fetch_all(MYSQLI_ASSOC);
	$name = isset($_POST["uname"])? $_POST["uname"] : "";
	$upwd = isset($_POST["upwd"])? $_POST["upwd"] : "";
	
	


	$nameRes = $conn -> query('select * from reg where uname="'
		.$name.'"');
	$nameArr = $nameRes -> fetch_all(MYSQLI_ASSOC);


	$upwdRes = $conn -> query('select * from reg where uname="'
		.$name.'" and upwd="'.$upwd.'"');
    $upwdArr = $upwdRes -> fetch_all(MYSQLI_ASSOC);
    // echo json_encode($upwdArr);
	// print_r($upwdArr);

	if(count($nameArr) != 0&&count($upwdArr) == 0){
        echo "true false";
    }else if(count($nameArr) == 0&&count($upwdArr) == 0){
        echo "false false";
    }else if(count($upwdArr) != 0){
    	echo "true true";
    }
		       
	


	
    
	$result->close();
	$conn->close();
	
	// include "connect.php";
   
	// $name = isset($_GET["uname"])? $_GET["uname"] : "";
	// $upwd = isset($_GET["upwd"])? $_GET["upwd"] : "";
	// $result = $conn -> query('select * from reg');
    // $res = $result->fetch_all(MYSQLI_ASSOC);
    // // var_dump($res);
    // foreach($res as $item){
            
    //         if($item ['uname'] == $uname && $item ['upwd']== $upwd){
    //              echo "true";
    //              break;
    //         }
    //         // var_dump( $item ['passwords']);
    //     }
        
    //     $result->close();
    //     $conn->close();

?>

