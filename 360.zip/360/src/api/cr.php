<?php
    $uname = isset($_POST["uname"])? $_POST["uname"] : "666";
    $upwds = isset($_POST["upwd"])? $_POST["upwd"] : "0055";

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = 'h5_1901';
    $conn = new mysqli($servername, $username, $password, $dbname);
    $conn->set_charset('utf8');
    $res = $conn ->query('insert into reg(uname,upwd)values("'.$uname.'","'.$upwds.'")');
    if ($res) {
        echo "true";
    } else {
        echo "Error: " . $res . "<br>" . $conn->error;
    }





?>