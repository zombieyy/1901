<?php
	   $name = isset($_GET["uname"])? $_GET["uname"] : "666";
       // var_dump($uname);
    //    $servername = "localhost";
    //    $username = "root";
    //    $password = "";
    //    $dbname = 'h5-1901';
    //    $conn = new mysqli($servername, $username, $password, $dbname);
   
   include "connect.php";
   
           $conn->set_charset('utf8');
       
           $result = $conn->query("select * from reg where uname='".$name."'");
	     
           
        //    $result = $conn -> query('select * from reg');
           $res = $result->fetch_all(MYSQLI_ASSOC);
           // var_dump($res);
           
           foreach($res as $item){
               
               if($item ['uname']== $name){
                    echo "true";
                    break;
               }
               
           }
           
           $result->close();
           $conn->close();
   
   
	




?>