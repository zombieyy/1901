<?php

include "connect.php";
 $id = isset($_POST["id"])? $_POST["id"] : "";
 $uname=isset($_POST["uname"])?$_POST["uname"] : "";
 $name = isset($_POST["name"])? $_POST["name"] : "";
 $imgurl = isset($_POST["imgurl"])? $_POST["imgurl"] : "";
 $price = isset($_POST["price"])? $_POST["price"] : "";
 $xiaoji = isset($_POST["xiaoji"])? $_POST["xiaoji"] : "";
    $qty = isset($_POST["qty"])? $_POST["qty"] : "";

    $result = $conn -> query('select * from car where name="'.$name.'" and id="'.$id.'"');
    $c = $result -> fetch_assoc();
    if($c){
        $qty = ++$c["qty"];
        $res = $conn->query("update car set qty=".$qty." where id=".$id);
     }else{
         $res = $conn ->query('insert into car(id,uname,imgurl,name,price,xiaoji,qty)values("'.$id.'","'.$uname.'","'.$imgurl.'","'.$name.'","'.$price.'","'.$xiaoji.'","'.$qty.'")');
     }
 
     if ($res) {
        echo "true";
    } else {
        echo "Error: " . $res . "<br>" . $conn->error;
    }



?>