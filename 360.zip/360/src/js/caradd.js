jQuery(function($){



//   $caradd = $(".caradd");
//     // if($.cookie("uname") != null){
//         // $add = $(".jia");
//         // $del = $(".jian");
//         // $input = $(".goodsCount");
//         // $a = 1;
//         // $add.on("click",function(){
//         //     // console.log() ;
//         //     // var a = parseInt($input.val());
//         //     $a++;
//         //      $input.val($a);
//         //       // console.log($input.val());
//         //       $qty=$input.val();
//         // })
//         // $del.on("click",function(){
//         //     $a--;
//         //     if($a < 1){
//         //         $a = 1;
//         //     }
//         //      $input.val($a);
//         //       $qty=$input.val();
//         //     })
//         $uname=$.cookie("$uname");
//         $price=paramsObj.price;
//         $name=paramsObj.name;
//         $id=paramsObj.id;
//         $xiaoji=$price,
//         $imgurl=$(".tu").attr("src");
//         console.log($uname);
//         $caradd.on("click",function(){
//             console.log(666);
//             $.ajax({
//                 url: '../api/caradd.php',
//                 type: 'POST',
//                 data: { id :$id,
//                     name:$name,
//                     uname:uname,
//                     imgurl:$imgurl,
//                     price:$price,
//                      qty:$qty,
                       
//                      xiaoji:$xiaoji,
                      
//                 success: function(data){

//                         if(data == "true"){
//                             alert("插入成功");
//                             }
//                             else{
//                                 $carAdd.on("click",function(){
//                                     $carAdd.attr("href","../html/denglu.html");
//                                 })
//                              }
//                         }
//                     }
//                 }) 
//         }
//         )
    // }

})