// jQuery(function(){
// 	$uname = $(".uname");
// 	$s0 = $(".s0");
// 	$upwd = $(".upwd");
// 	$s1 = $(".s1");
// 	$dlbtn = $(".tj");

// 	$uname.blur(function(){
// 		var _uname = $uname.val();
// 		console.log(_uname);

// 		$.ajax({
// 			url:"../api/login.php",
// 			type:"get",
// 			data:{"_uname":_uname},
// 			dataType:"json",
// 			success: succFunction4,
// 			error:function(){console.log(111);}
// 		})
// 		function succFunction4(data){
// 			console.log(data);
// 			$.ajax({
// 				url:"../api/login.php",
// 				type:"get",
// 				data:{"_uname":_uname},
// 				dataType:"json",
// 				success: succFunction5,
// 				error:function(){console.log(222);}
// 			})
// 			function succFunction5(data){
// 				console.log(typeof(data));
// 				console.log($s0);
// 				data = data.split(" ")
// 				console.log(data[0]);
// 				if(data[0] == "false"){
// 						$s0.css("display","block");
// 			            $s0.html("用户名不存在");
// 			        }else if(data[0] == "true"){
// 						$s0.css("display","none");
			          
// 			        }
// 			}
// 		}
// 	})

// 	$dlbtn.on("click",function(){
// 		_uname = $uname.val();
//    		_upwd = $upwd.val();
//    		$.ajax({
// 			url:"../api/login.php",
// 			type:"get",
// 			data:{"_uname":_uname,"_upwd":_upwd},
// 			dataType:"json",
// 			success: succFunction6,
// 			error:function(){console.log(555);}
// 		})
// 		function succFunction6(data){
// 			console.log(data);
// 			data = data.split(" ")
// 			console.log(data[1]);
// 			if(data[1] == "false"){
// 				alert("用户名或密码错误，请重新输入");
// 	        }else if(data[1] == "true"){
// 				alert("登录成功");
	         
// 	        }
// 		}
		
// 	})
	
// })
// jQuery(function($){

//     $uname = $("..uname");
//     $upwd = $(".upwd");
//     $dlbtn = $(".tj");
//     var aaa = "";
    
       
//              $dlbtn.on("mousedown",function(){
//                 console.log(666);

//                 $uname = $uname.val();
//                 $upwd = $upwd.val();

//                 $.ajax({
//                     url: '../api/login.php',
//                     type: 'GET',
//                     data: {uname: $uname,
//                             upwd: $upwd},
//                     success: function(data){
//                             if(data == "true"){
//                                 $dlbtn.attr(
//                                    'href', '../index.html');
//                                     $.cookie("uname", $uname,{path: '/'});
//                                 }else{
//                                 alert("账号或密码错误");
//                             }
//                         } 
//                     })  
//              })

        

      
        
//         // =============================
            
           
        
        
        
        
            
//     })
jQuery(function(){
console.log(123);
        $dlbtn = $(".ldtn");
        $dlbtn.on("click",function(){
            $uname = $(".uname").val();
            $upwd = $(".upwd").val();
            $.ajax({
                url:"../api/login.php",
                type:"post",
                data:"uname="+$uname+"&upwd="+$upwd,
                success:function(data){
                   data= data.trim().split(" ");
                   console.log(data[1])
                  
                    if(data[0]=="false"&&data[1]=="false"){
                        alert("弱智玩意 密码账号都错了")
                    }if(data[0]=="true"&&data[1]=="false"){
                        alert("弱智玩意 密码错了")
                    }if(data[0]=="true"&&data[1]=="true"){
                        alert("登录成功")
                        location.href = "../index.html";
                        $.cookie("uname", $uname,{path: '/'});
                    }
                }
            })
            
        })


})