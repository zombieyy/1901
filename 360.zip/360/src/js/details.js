jQuery(function($){
 
    $tu = $(".tu");
    $name=$(".name");
    $price=$(".price");
    var $qty;


    var params = decodeURI(location.search).slice(1,-1);
 
    var paramsArr = params.split("&");

    var paramsObj = {};
    paramsArr.forEach(function(item){
        var arr = item.split("=");
        paramsObj[arr[0]] = arr[1];
    });
  
    if(!/^..\//.test(paramsObj.imgurl)){

        $tu.attr("src","../"+paramsObj.imgurl);
       
        $name.append(paramsObj.name);
      
        $price.text(paramsObj.price);
     


    }else{
        $tu.attr("src",paramsObj.imgurl);
       
        $name.append(paramsObj.name);
     
        $price.text(paramsObj.price);
       
        
    }
//  $caradd = $(".caradd");
//  $.ajax({
//     url: '../api/caradd.php',
//     type: 'POST',
//     data:{ id :$id,
//            uname:uname,
//             price:$price,
//             imgurl:$imgurl,
//             name=$name,
//             xiaoji:$xiaoji,
//             qty:$qty,
//              success: function(data){
    
//             if(data == "true"){
//              alert("插入成功");
//                                 }
                                
//                             }
//                         }
//  })


        $caradd = $(".caradd");
        $uname=$.cookie("$uname");
        $price=paramsObj.price;
        $name=paramsObj.name;
        $id=paramsObj.id;
        $xiaoji=$price,
        $imgurl=$(".tu").attr("src");
  
    // if($.cookie("uname") != null){
    
    //     $add = $(".jia");
    //     $del = $(".jian");
    //     $input = $(".goodsCount");
    //     $a = 1;
    //     $add.on("click",function(){
    //         // console.log() ;
    //         // var a = parseInt($input.val());
    //         $a++;
    //          $input.val($a);
    //           // console.log($input.val());
    //           $qty=$input.val();
    //     })
    //     $del.on("click",function(){
    //         $a--;
    //         if($a < 1){
    //             $a = 1;
    //         }
    //          $input.val($a);
    //           $qty=$input.val();
    //     })
    //     $uname=$.cookie("$uname");
    //     $price=paramsObj.price;
    //     $name=paramsObj.name;
    //     $id=paramsObj.id;
    //     $xiaoji=$price,
    //     $imgurl=$(".tu").attr("src");
    //     console.log($uname,$price,$imgurl,$name,$xiaoji,$qty)
    //     $caradd.on("click",function(){
            
            // $.ajax({
            //     url: '../api/caradd.php',
            //     type: 'post',
               
            //     data: { id :$id,
            //         uname:$uname,
            //          price:$price,
            //             imgurl:$imgurl,
            //            name=$name,
            //            xiaoji:$xiaoji,
            //            qty:$qty},
            //      dataType: "json",
            //     // success: function(data){
            //     //     console.log(data)
            //     //         // if(data == "true"){
            //     //         //     alert("插入成功");
                            
            //     //         // }
            //     //     }
            // }) 
        
    // })
    // }
})
