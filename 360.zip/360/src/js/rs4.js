jQuery(function(){

    var rsb = document.querySelector(".rsb");
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function(){
        var status = [200,304];
        if(xhr.readyState == 4 && status.indexOf(xhr.status) != -1){
            var res = JSON.parse(xhr.responseText);//json字符串==>json对象
            rsb.innerHTML = res.map(function(item){
    
                var {id,imgurl,name,price} = item;
                return `<li data-id="${id}">
                         <a href="html/list.html">
                         <img src= "${imgurl}" alt="" />
                         <span>${name}</span>
                         <p>¥:${price}</p>
                         
                         </a>
                </li>`;
            }).join("");
        // cookie
        rsb.onclick = function(e){
        var target = e.target;     
         if(target.tagName.toLowerCase() === 'img'){
            var currendGuid = target.parentElement.parentElement.getAttribute('data-id');
            var currentGoods = res.filter(function(item){
            return item.id === currendGuid;
            })[0]
            var now = new Date();
            now.setDate(now.getDate()+3);
            document.cookie = 'currentGoods=' + JSON.stringify(currentGoods) + ';expires=' + now;
         }
    }
        }
    }
    xhr.open("get","data/rs4.json");
            xhr.send();
         





})
