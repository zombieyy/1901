var output = document.querySelector(".output");
var xhr = new XMLHttpRequest();
xhr.onreadystatechange = function(){
    var status = [200,304];
    if(xhr.readyState == 4 && status.indexOf(xhr.status) != -1){
        var res = JSON.parse(xhr.responseText);//json字符串==>json对象
        output.innerHTML = res.map(function(item){

            var {id,imgurl,name,price} = item;
            return `<li data-id="${id}">
                     <a href="html/list.html">
                     <img src= "${imgurl}" alt="" />
                     <span>${name}</span>
                     <p>¥:${price}</p>
                     
                     </a>
            </li>`;
        }).join("");
    // cookie
    output.onclick = function(e){
    var target = e.target;     
     if(target.tagName.toLowerCase() === 'img'){
        var currendGuid = target.parentElement.parentElement.getAttribute('data-id');
        var currentGoods = res.filter(function(item){
        return item.id === currendGuid;
        })[0]
        var now = new Date();
        now.setDate(now.getDate()+3);
        document.cookie = 'currentGoods=' + JSON.stringify(currentGoods) + ';expires=' + now;
     }
}
    }
}
xhr.open("get","data/rs1.json");
        xhr.send();
        console.log(6666);