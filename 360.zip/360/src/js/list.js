var img = document.querySelector("#xq .bl");
var xq1= document.querySelector("#xq .b1");
var xq2= document.querySelector("#xq .b2");
var currentGoods;
var historyList=[];
render();
function render(){
    var cookie = document.cookie.split('; ');
    cookie.forEach(function(item){
    var arr = item.split('=');
    if(arr[0] === 'currentGoods'){
        currentGoods = JSON.parse(arr[1]);
    }else if(arr[0] === 'historyList'){
        historyList = JSON.parse(arr[1]);
    }
});
img.innerHTML="<img src= ' ../"+currentGoods.imgurl+"'/>"
xq1.innerHTML ="<h5>"+currentGoods.name+"</h5>"+
"<span>"   +currentGoods.price+ "</span>"+ "<i>¥</i>"

                      
// xq1.innerHTML=" "<h3>"+currentGoods.title+"</h3>"
}
  var add = document.querySelector(".add");
  add.onclick=function(){
      var i;
      var has 
  }



// var add = document.querySelector("#main .m1_r .m1_r4 .add");
// add.onclick = function(){
//     var i;
//     var has = historyList.some(function(item,idx){
//         i = idx;
//         return item.id == currentGoods.id;
//     })
//     if(has){
//          historyList[i].qty++;
//     }else{
//         historyList.unshift(currentGoods);
//     }
// var now = new Date();
// now.setDate(now.getDate()+3);
// document.cookie = 'historyList=' + JSON.stringify(historyList) + ';expires=' + now;
// }
