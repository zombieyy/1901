jQuery(function($){
    $shows = $(".wp1");
    $jiage = $(".jiage");
    var shangpin = new Array;

// =======totop============
  
// ================
    $.ajax({
            url: '../api/good.php',
            type: 'GET',
            success: function (data){
                var data = JSON.parse(data);
                // var shangpin = new Array;
                var priceArr = new Array;
              
                huan1();
                 
                 function huan1(){
                   priceArr = [];
                   shangpin = data.slice(0, 20);
                   shuchu(shangpin);
                 }

               
               
                
                // =======换页==========
                console.log($(".tow"));
                function huan2(){
                   priceArr = [];
                   shangpin = data.slice(21, 41);
                   shuchu(shangpin);
                  
                }
                function huan3(){
                   priceArr = [];
                   shangpin = data.slice(41, 61);
                   shuchu(shangpin);
                }
                function huan4(){
                   priceArr = [];
                   shangpin = data.slice(61, 81);
                   shuchu(shangpin);
                }
                $(".one").on("click",function(){
                  
                    huan1();
                  })
               $(".tow").on("click",function(){
                
                  huan2();
               
              })
               
                  

                $(".three").on("click",function(){
                   huan3();
            
                })
                $(".four").on("click",function(){
                  huan4();
                  
                })
                  console.log($(".xia"));
                  var p = new Promise(function(resolve, reject){ 
                    //做一些异步操作 
                    $(".xia").on("click",function(){
                      huan2();
                      resolve(); 
                    })
                   
                  }); 
                  p.then(function(){
                     $(".xia").on("click",function(){
                       huan3();
                      })
                     
                  }) 
                 p.then(function(){
                   $(".xia").on("click",function(){

                      
                       huan4();
                        })
                  }) 
                shuchu(shangpin);
                // ==========把商品输出到页面
                 function shuchu(){
                    $shows.empty();
                     for(var i=0;i<shangpin.length;i++){
                          $shows.append( `	<div class="xqb fl">
                          <a class="a1">
                          <img src="${shangpin[i].imgurl}" shangpin-guid="${shangpin[i].id}" style="display:inline;">
                          <p>${shangpin[i].name}</p>
                          <p class="price">¥${shangpin[i].price}</p>
                            
                           
                            </a>
                            </div>` );
                          priceArr.push(shangpin[i]);
                      }
                      zhixing();
                 }
            
                 // 排序==========================
                   var da = true;
                $jiage.on("click",function(){
                    // console.log(priceArr);
                    if(da == true){
                        var res = priceArr.sort(function(a,b){
                        return a.price - b.price;
                        
                        });
                          paixu();
                    }else if(da == false){
                         var res = priceArr.sort(function(a,b){
                         return b.price - a.price;
                         });
                         paixu();
                    }
                    da = ! da;
                    console.log(res);
                    function paixu(){
                        $shows.empty();
                    for(var i =0;i<res.length;i++){
                        console.log(res);
                        
                         $shows.append( `	
                         <div class="xqb fl">
                        <a class="a1">
                         <img src="${res[i].imgurl}"shangping-guid="${res[i].id}" style="display:inline;">
                         <p>${res[i].name}</p>
                         <p class="price">¥${res[i].price}</p>
                           
                         </a>
                           
                           </div>` );
                    }
                    zhixing();
                }
                     
                     
                })
               
               

                // =================传数据到详情页=========
                function zhixing(){
                     $(".xqb").each(function(idx,item){
                          
                           item.onclick = function(){
                               
                                 var str = "";
                                for(var key in priceArr[idx]){
                                    str += key + "=" + priceArr[idx][key] + "&";
                                }
                                str = str.slice(0,-1);
                                location.href = "details.html?" + encodeURI(str);
                                console.log(str);
                           }

            }); 
                }
                zhixing();

                
            }
                         
        })
       
 
   
})



















